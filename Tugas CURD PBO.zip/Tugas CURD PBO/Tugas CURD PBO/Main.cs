﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tugas_CURD_PBO
{
    public partial class Form1 : Form
    {
        public DatabaseAccess database;
        public DateTime ttg = DateTime.Now;
        public Form1()
        {
            InitializeComponent();
            default_tabel();
            default_belanja();
            tanggal.Text = ttg.ToString("d MMMM yyyy");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void pencarian_barang_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(pencarian_barang.Text))
            {
                database = new Tugas_CURD_PBO.DatabaseAccess("localhost", "Ini_toko", "postgres", "132435");
                database.OpenConnection();
                DataTable tabel = database.ExecuteQuery($"SELECT * FROM Barang WHERE lower(nama_barang) LIKE lower('%{pencarian_barang.Text}%')");

                if (tabel.Rows.Count > 0)
                {
                    Tabel_Barang.DataSource = tabel;
                    Tabel_Barang.DefaultCellStyle.Font = new Font("Arial", 12);
                    Tabel_Barang.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 12);

                    Tabel_Barang.Columns["id_barang"].HeaderText = "ID Barang";
                    Tabel_Barang.Columns["nama_barang"].HeaderText = "Nama Barang";
                    Tabel_Barang.Columns["jumlah_barang"].HeaderText = "Jumlah Barang";
                    Tabel_Barang.Columns["harga_barang"].HeaderText = "Harga Barang";
                }
                else
                {
                    MessageBox.Show("Data tidak ditemukan.");
                }
            }
            else
            {
                default_tabel();
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            
        }
        
        public void default_tabel()
        {
            database = new Tugas_CURD_PBO.DatabaseAccess("localhost", "Ini_toko", "postgres", "132435");
            database.OpenConnection();
            DataTable tabel = database.ExecuteQuery("SELECT * FROM Barang where jumlah_barang > 0");
            Tabel_Barang.DataSource = tabel;
            Tabel_Barang.DefaultCellStyle.Font = new Font("Arial", 12);
            Tabel_Barang.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 12);

            Tabel_Barang.Columns["id_barang"].HeaderText = "ID Barang";
            Tabel_Barang.Columns["nama_barang"].HeaderText = "Nama Barang";
            Tabel_Barang.Columns["jumlah_barang"].HeaderText = "Jumlah Barang";
            Tabel_Barang.Columns["harga_barang"].HeaderText = "Harga Barang";
            database.CloseConnection();
        }
        public void default_belanja()
        {
/*            database = new Tugas_CURD_PBO.DatabaseAccess("localhost", "Ini_toko", "postgres", "132435");
            database.OpenConnection();
            DataTable tabel = database.ExecuteQuery("SELECT * FROM Barang where jumlah_barang > 0");
            Tabel_Barang.DataSource = tabel;
            Tabel_Barang.DefaultCellStyle.Font = new Font("Arial", 12);
            Tabel_Barang.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 12);

            Tabel_Barang.Columns["id_barang"].HeaderText = "ID Barang";
            Tabel_Barang.Columns["nama_barang"].HeaderText = "Nama Barang";
            Tabel_Barang.Columns["jumlah_barang"].HeaderText = "Jumlah Barang";
            Tabel_Barang.Columns["harga_barang"].HeaderText = "Harga Barang";
            database.CloseConnection();*/
        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panelHeader_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Tabel_Barang_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel_ListBarang_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click_2(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            setting settings = new setting();
            settings.Show();
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void tanggal_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_3(object sender, EventArgs e)
        {
            if(!(textBox_addIDBarang.Text == "ID Barang" || textBox_AddJumlah.Text == "Jumlah Barang"))
            {

            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}

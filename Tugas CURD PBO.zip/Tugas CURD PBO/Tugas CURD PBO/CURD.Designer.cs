﻿namespace Tugas_CURD_PBO
{
    partial class setting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_AddData = new System.Windows.Forms.Button();
            this.body = new System.Windows.Forms.Panel();
            this.Tarik_barang = new System.Windows.Forms.Button();
            this.buttonEdit_barang = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.body.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_AddData
            // 
            this.button_AddData.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_AddData.Location = new System.Drawing.Point(97, 134);
            this.button_AddData.Name = "button_AddData";
            this.button_AddData.Size = new System.Drawing.Size(491, 131);
            this.button_AddData.TabIndex = 0;
            this.button_AddData.Text = "Tambah Barang";
            this.button_AddData.UseVisualStyleBackColor = true;
            this.button_AddData.Click += new System.EventHandler(this.button1_Click);
            // 
            // body
            // 
            this.body.Controls.Add(this.Tarik_barang);
            this.body.Controls.Add(this.buttonEdit_barang);
            this.body.Controls.Add(this.button_AddData);
            this.body.Location = new System.Drawing.Point(0, 102);
            this.body.Name = "body";
            this.body.Size = new System.Drawing.Size(1212, 601);
            this.body.TabIndex = 2;
            // 
            // Tarik_barang
            // 
            this.Tarik_barang.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tarik_barang.Location = new System.Drawing.Point(378, 337);
            this.Tarik_barang.Name = "Tarik_barang";
            this.Tarik_barang.Size = new System.Drawing.Size(491, 131);
            this.Tarik_barang.TabIndex = 2;
            this.Tarik_barang.Text = "Tarik Barang";
            this.Tarik_barang.UseVisualStyleBackColor = true;
            this.Tarik_barang.Click += new System.EventHandler(this.Tarik_barang_Click);
            // 
            // buttonEdit_barang
            // 
            this.buttonEdit_barang.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEdit_barang.Location = new System.Drawing.Point(666, 134);
            this.buttonEdit_barang.Name = "buttonEdit_barang";
            this.buttonEdit_barang.Size = new System.Drawing.Size(491, 131);
            this.buttonEdit_barang.TabIndex = 1;
            this.buttonEdit_barang.Text = "Edit Barang";
            this.buttonEdit_barang.UseVisualStyleBackColor = true;
            this.buttonEdit_barang.Click += new System.EventHandler(this.buttonEdit_barang_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(561, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 36);
            this.label1.TabIndex = 1;
            this.label1.Text = "Database";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // setting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(241)))), ((int)(((byte)(241)))));
            this.ClientSize = new System.Drawing.Size(1212, 703);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.body);
            this.Name = "setting";
            this.Text = "Settings";
            this.Load += new System.EventHandler(this.setting_Load);
            this.body.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_AddData;
        private System.Windows.Forms.Panel body;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonEdit_barang;
        private System.Windows.Forms.Button Tarik_barang;
    }
}
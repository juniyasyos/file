﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tugas_CURD_PBO
{
    public partial class setting : Form
    {
        public Form1 form;
        public setting()
        {
            InitializeComponent();
        }

        private void setting_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Barang ";
            CURD curd = new CURD(query,"add");
            curd.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button_Edit_Click(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void buttonEdit_barang_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Barang SET";
            CURD curd = new CURD(query, "update");
            curd.Show();
        }

        private void Tarik_barang_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM public.barang";
            CURD curd = new CURD(query,"del");
            curd.Show();
        }
    }
}

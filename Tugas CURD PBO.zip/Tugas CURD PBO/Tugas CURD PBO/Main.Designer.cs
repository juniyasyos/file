﻿namespace Tugas_CURD_PBO
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelSearch = new System.Windows.Forms.Panel();
            this.pencarian_barang = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panelTotal = new System.Windows.Forms.Panel();
            this.labelTOTAL = new System.Windows.Forms.Label();
            this.labelTotalHarga = new System.Windows.Forms.Label();
            this.panel_daftarBarang = new System.Windows.Forms.Panel();
            this.Tabel_Barang = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel_ListBarang = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_AddJumlah = new System.Windows.Forms.TextBox();
            this.textBox_addIDBarang = new System.Windows.Forms.TextBox();
            this.Riwayat_transaksi = new System.Windows.Forms.Button();
            this.npgsqlCommandBuilder1 = new Npgsql.NpgsqlCommandBuilder();
            this.settings = new System.Windows.Forms.Button();
            this.Header = new System.Windows.Forms.Panel();
            this.tanggal = new System.Windows.Forms.Label();
            this.Nama_toko = new System.Windows.Forms.Label();
            this.panelSearch.SuspendLayout();
            this.panelTotal.SuspendLayout();
            this.panel_daftarBarang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Tabel_Barang)).BeginInit();
            this.panel_ListBarang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.Header.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelSearch
            // 
            this.panelSearch.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelSearch.AutoSize = true;
            this.panelSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(124)))), ((int)(((byte)(35)))));
            this.panelSearch.Controls.Add(this.pencarian_barang);
            this.panelSearch.Controls.Add(this.label2);
            this.panelSearch.Location = new System.Drawing.Point(0, 65);
            this.panelSearch.Name = "panelSearch";
            this.panelSearch.Size = new System.Drawing.Size(517, 100);
            this.panelSearch.TabIndex = 1;
            // 
            // pencarian_barang
            // 
            this.pencarian_barang.Font = new System.Drawing.Font("Microsoft JhengHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pencarian_barang.Location = new System.Drawing.Point(18, 37);
            this.pencarian_barang.Name = "pencarian_barang";
            this.pencarian_barang.Size = new System.Drawing.Size(379, 27);
            this.pencarian_barang.TabIndex = 4;
            this.pencarian_barang.TextChanged += new System.EventHandler(this.pencarian_barang_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 22);
            this.label2.TabIndex = 3;
            this.label2.Text = "Tambah Item";
            // 
            // panelTotal
            // 
            this.panelTotal.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelTotal.AutoSize = true;
            this.panelTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(124)))), ((int)(((byte)(35)))));
            this.panelTotal.Controls.Add(this.labelTOTAL);
            this.panelTotal.Controls.Add(this.labelTotalHarga);
            this.panelTotal.Location = new System.Drawing.Point(518, 65);
            this.panelTotal.Name = "panelTotal";
            this.panelTotal.Size = new System.Drawing.Size(700, 100);
            this.panelTotal.TabIndex = 2;
            // 
            // labelTOTAL
            // 
            this.labelTOTAL.AutoSize = true;
            this.labelTOTAL.Font = new System.Drawing.Font("MS Reference Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTOTAL.Location = new System.Drawing.Point(132, 59);
            this.labelTOTAL.Name = "labelTOTAL";
            this.labelTOTAL.Size = new System.Drawing.Size(61, 22);
            this.labelTOTAL.TabIndex = 6;
            this.labelTOTAL.Text = "Rp. 0";
            // 
            // labelTotalHarga
            // 
            this.labelTotalHarga.AutoSize = true;
            this.labelTotalHarga.Font = new System.Drawing.Font("MS Reference Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotalHarga.Location = new System.Drawing.Point(3, 3);
            this.labelTotalHarga.Name = "labelTotalHarga";
            this.labelTotalHarga.Size = new System.Drawing.Size(120, 22);
            this.labelTotalHarga.TabIndex = 5;
            this.labelTotalHarga.Text = "Total Harga";
            // 
            // panel_daftarBarang
            // 
            this.panel_daftarBarang.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_daftarBarang.AutoSize = true;
            this.panel_daftarBarang.BackColor = System.Drawing.Color.White;
            this.panel_daftarBarang.Controls.Add(this.Tabel_Barang);
            this.panel_daftarBarang.Controls.Add(this.label3);
            this.panel_daftarBarang.Location = new System.Drawing.Point(0, 165);
            this.panel_daftarBarang.Name = "panel_daftarBarang";
            this.panel_daftarBarang.Size = new System.Drawing.Size(711, 489);
            this.panel_daftarBarang.TabIndex = 3;
            // 
            // Tabel_Barang
            // 
            this.Tabel_Barang.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Tabel_Barang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.Tabel_Barang.BackgroundColor = System.Drawing.Color.White;
            this.Tabel_Barang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("MS Outlook", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Tabel_Barang.DefaultCellStyle = dataGridViewCellStyle1;
            this.Tabel_Barang.GridColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Tabel_Barang.Location = new System.Drawing.Point(12, 36);
            this.Tabel_Barang.Name = "Tabel_Barang";
            this.Tabel_Barang.RowHeadersWidth = 51;
            this.Tabel_Barang.RowTemplate.Height = 24;
            this.Tabel_Barang.Size = new System.Drawing.Size(629, 447);
            this.Tabel_Barang.TabIndex = 1;
            this.Tabel_Barang.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Tabel_Barang_CellContentClick);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(15, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 20);
            this.label3.TabIndex = 0;
            this.label3.Text = "Daftar Barang";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(171, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(183, 22);
            this.label4.TabIndex = 1;
            this.label4.Text = "BARANG PEMBELIAN";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // panel_ListBarang
            // 
            this.panel_ListBarang.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_ListBarang.AutoSize = true;
            this.panel_ListBarang.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(170)))), ((int)(((byte)(66)))));
            this.panel_ListBarang.Controls.Add(this.dataGridView1);
            this.panel_ListBarang.Controls.Add(this.label7);
            this.panel_ListBarang.Controls.Add(this.label6);
            this.panel_ListBarang.Controls.Add(this.button1);
            this.panel_ListBarang.Controls.Add(this.label5);
            this.panel_ListBarang.Controls.Add(this.textBox_AddJumlah);
            this.panel_ListBarang.Controls.Add(this.textBox_addIDBarang);
            this.panel_ListBarang.Controls.Add(this.label4);
            this.panel_ListBarang.Location = new System.Drawing.Point(717, 171);
            this.panel_ListBarang.Name = "panel_ListBarang";
            this.panel_ListBarang.Size = new System.Drawing.Size(501, 483);
            this.panel_ListBarang.TabIndex = 4;
            this.panel_ListBarang.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_ListBarang_Paint);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(16, 136);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(360, 341);
            this.dataGridView1.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.NavajoWhite;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(171, 71);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(99, 18);
            this.label7.TabIndex = 10;
            this.label7.Text = "Jumlah Barang";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.NavajoWhite;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(16, 71);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 18);
            this.label6.TabIndex = 9;
            this.label6.Text = "ID Barang";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(374, 92);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "Tambah";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_3);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(16, 45);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(154, 22);
            this.label5.TabIndex = 7;
            this.label5.Text = "Tambah Pembelian";
            // 
            // textBox_AddJumlah
            // 
            this.textBox_AddJumlah.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_AddJumlah.Location = new System.Drawing.Point(171, 92);
            this.textBox_AddJumlah.Name = "textBox_AddJumlah";
            this.textBox_AddJumlah.Size = new System.Drawing.Size(148, 22);
            this.textBox_AddJumlah.TabIndex = 6;
            // 
            // textBox_addIDBarang
            // 
            this.textBox_addIDBarang.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_addIDBarang.Location = new System.Drawing.Point(16, 92);
            this.textBox_addIDBarang.Name = "textBox_addIDBarang";
            this.textBox_addIDBarang.Size = new System.Drawing.Size(100, 22);
            this.textBox_addIDBarang.TabIndex = 4;
            this.textBox_addIDBarang.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Riwayat_transaksi
            // 
            this.Riwayat_transaksi.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Riwayat_transaksi.Location = new System.Drawing.Point(1016, 668);
            this.Riwayat_transaksi.Name = "Riwayat_transaksi";
            this.Riwayat_transaksi.Size = new System.Drawing.Size(184, 23);
            this.Riwayat_transaksi.TabIndex = 5;
            this.Riwayat_transaksi.Text = "Riwayat Transaksi";
            this.Riwayat_transaksi.UseVisualStyleBackColor = true;
            this.Riwayat_transaksi.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // npgsqlCommandBuilder1
            // 
            this.npgsqlCommandBuilder1.QuotePrefix = "\"";
            this.npgsqlCommandBuilder1.QuoteSuffix = "\"";
            // 
            // settings
            // 
            this.settings.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.settings.Location = new System.Drawing.Point(862, 668);
            this.settings.Name = "settings";
            this.settings.Size = new System.Drawing.Size(148, 23);
            this.settings.TabIndex = 6;
            this.settings.Text = "Settings";
            this.settings.UseVisualStyleBackColor = true;
            this.settings.Click += new System.EventHandler(this.button2_Click);
            // 
            // Header
            // 
            this.Header.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(84)))), ((int)(((byte)(100)))));
            this.Header.Controls.Add(this.tanggal);
            this.Header.Controls.Add(this.Nama_toko);
            this.Header.Location = new System.Drawing.Point(3, 4);
            this.Header.Name = "Header";
            this.Header.Size = new System.Drawing.Size(1215, 58);
            this.Header.TabIndex = 7;
            // 
            // tanggal
            // 
            this.tanggal.AutoSize = true;
            this.tanggal.Font = new System.Drawing.Font("MS Reference Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tanggal.ForeColor = System.Drawing.Color.White;
            this.tanggal.Location = new System.Drawing.Point(1069, 33);
            this.tanggal.Name = "tanggal";
            this.tanggal.Size = new System.Drawing.Size(128, 22);
            this.tanggal.TabIndex = 7;
            this.tanggal.Text = "18 Mei 2023";
            this.tanggal.Click += new System.EventHandler(this.tanggal_Click);
            // 
            // Nama_toko
            // 
            this.Nama_toko.AutoSize = true;
            this.Nama_toko.Font = new System.Drawing.Font("MS Reference Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nama_toko.ForeColor = System.Drawing.Color.White;
            this.Nama_toko.Location = new System.Drawing.Point(5, 14);
            this.Nama_toko.Name = "Nama_toko";
            this.Nama_toko.Size = new System.Drawing.Size(134, 22);
            this.Nama_toko.TabIndex = 6;
            this.Nama_toko.Text = "INI WARUNG";
            this.Nama_toko.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(241)))), ((int)(((byte)(241)))));
            this.ClientSize = new System.Drawing.Size(1212, 703);
            this.Controls.Add(this.Header);
            this.Controls.Add(this.settings);
            this.Controls.Add(this.Riwayat_transaksi);
            this.Controls.Add(this.panel_daftarBarang);
            this.Controls.Add(this.panelTotal);
            this.Controls.Add(this.panelSearch);
            this.Controls.Add(this.panel_ListBarang);
            this.Font = new System.Drawing.Font("MS Outlook", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.Name = "Form1";
            this.Text = "toko abah";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelSearch.ResumeLayout(false);
            this.panelSearch.PerformLayout();
            this.panelTotal.ResumeLayout(false);
            this.panelTotal.PerformLayout();
            this.panel_daftarBarang.ResumeLayout(false);
            this.panel_daftarBarang.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Tabel_Barang)).EndInit();
            this.panel_ListBarang.ResumeLayout(false);
            this.panel_ListBarang.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.Header.ResumeLayout(false);
            this.Header.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panelSearch;
        private System.Windows.Forms.TextBox pencarian_barang;
        private System.Windows.Forms.Panel panelTotal;
        private System.Windows.Forms.Label labelTOTAL;
        private System.Windows.Forms.Label labelTotalHarga;
        private System.Windows.Forms.Panel panel_daftarBarang;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel_ListBarang;
        private System.Windows.Forms.DataGridView Tabel_Barang;
        private System.Windows.Forms.Button Riwayat_transaksi;
        private Npgsql.NpgsqlCommandBuilder npgsqlCommandBuilder1;
        private System.Windows.Forms.Button settings;
        private System.Windows.Forms.Panel Header;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Nama_toko;
        private System.Windows.Forms.Label tanggal;
        private System.Windows.Forms.TextBox textBox_addIDBarang;
        private System.Windows.Forms.TextBox textBox_AddJumlah;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}


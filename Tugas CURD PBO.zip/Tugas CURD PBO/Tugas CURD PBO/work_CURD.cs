﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tugas_CURD_PBO
{
    public partial class CURD : Form
    {
        public DatabaseAccess database = new Tugas_CURD_PBO.DatabaseAccess("localhost", "Ini_toko", "postgres", "132435");
        public string query;
        public string status;
        public CURD(string query,string status)
        {
            InitializeComponent();
            default_tabel();
            this.query = query;
            this.status = status;
            if (status == "update")
            {
                Tambah_Data.Text = "Update Data";
            }else if(status == "add")
            {
                Tambah_Data.Text = "Tambah Data";
            }else if(status == "del")
            {
                Tambah_Data.Text = "Hapus Data";
                textBox_HargaBarang.Enabled = false;
                textBox_jmlBarang.Enabled = false;
                textBox_NamaBarang.Enabled = false;
            }
            else
            {
                MessageBox.Show("Terdapat kesalahan pada var status");
            }
        }

        private void panel_daftarBarang_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Tabel_Barang_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }
        public void default_tabel()
        {
            database = new Tugas_CURD_PBO.DatabaseAccess("localhost", "Ini_toko", "postgres", "132435");
            database.OpenConnection();
            DataTable tabel = database.ExecuteQuery("SELECT * FROM Barang where jumlah_barang > 0");
            Tabel_Barang.DataSource = tabel;
            Tabel_Barang.DefaultCellStyle.Font = new Font("Arial", 12);
            Tabel_Barang.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 12);

            Tabel_Barang.Columns["id_barang"].HeaderText = "ID Barang";
            Tabel_Barang.Columns["nama_barang"].HeaderText = "Nama Barang";
            Tabel_Barang.Columns["jumlah_barang"].HeaderText = "Jumlah Barang";
            Tabel_Barang.Columns["harga_barang"].HeaderText = "Harga Barang";
            database.CloseConnection();
        }

        // Pencarian ID
        private void textBox_IDData_TextChanged(object sender, EventArgs e)
        {
            string IDBarang = textBox_IDData.Text;
            int idBarang;
            bool isIdBarang = int.TryParse(IDBarang, out idBarang);
            if (isIdBarang && this.status!="add")
            {
                database = new Tugas_CURD_PBO.DatabaseAccess("localhost", "Ini_toko", "postgres", "132435");
                database.OpenConnection();
                DataTable tabel = database.ExecuteQuery($"SELECT * FROM Barang WHERE id_barang = {idBarang}");

                if (tabel.Rows.Count > 0)
                {
                    Tabel_Barang.DataSource = tabel;
                    Tabel_Barang.DefaultCellStyle.Font = new Font("Arial", 12);
                    Tabel_Barang.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 12);

                    Tabel_Barang.Columns["id_barang"].HeaderText = "ID Barang";
                    Tabel_Barang.Columns["nama_barang"].HeaderText = "Nama Barang";
                    Tabel_Barang.Columns["jumlah_barang"].HeaderText = "Jumlah Barang";
                    Tabel_Barang.Columns["harga_barang"].HeaderText = "Harga Barang";
                }
                else
                {
                    MessageBox.Show("Data tidak ditemukan.");
                }
            }
            else
            {
                default_tabel();
            }
        }

        private void Tambah_Data_Click(object sender, EventArgs e)
        {
            string IDBarang = textBox_IDData.Text;
            string namaBarang = textBox_NamaBarang.Text;
            string jumlahBarangString = textBox_jmlBarang.Text;
            string hargaBarangString = textBox_HargaBarang.Text;

            if (status == "add" && !string.IsNullOrEmpty(textBox_HargaBarang.Text) && !string.IsNullOrEmpty(textBox_IDData.Text) && !string.IsNullOrEmpty(textBox_jmlBarang.Text) && !string.IsNullOrEmpty(textBox_NamaBarang.Text))
            {
                database.OpenConnection();
                try
                {
                    decimal hargaBarang;
                    bool isHargaBarangValid = decimal.TryParse(hargaBarangString, out hargaBarang);
                    int idBarang;
                    bool isIdBarang = int.TryParse(IDBarang, out idBarang);
                    int jumlahBarang;
                    bool isJumlahBarangValid = int.TryParse(jumlahBarangString, out jumlahBarang);
                    if (isJumlahBarangValid && isIdBarang && isHargaBarangValid)
                    {
                        // Buat query INSERT
                        string query = $"{this.query}(id_barang, nama_barang, jumlah_barang, harga_barang) VALUES ('{idBarang}', '{namaBarang}', {jumlahBarang}, {hargaBarang})";
                        // textBox_IDData.Text = query ;
                        // Eksekusi query INSERT
                        bool isSuccess = database.ExecuteNonQuery(query);

                        if (isSuccess)
                        {
                            // Tampilkan data terbaru pada Tabel_Barang
                            default_tabel();
                            label_statusAktivitas.Text = "Status: Operasi Data Berhasil";
                        }
                        else
                        {
                            label_statusAktivitas.Text = "Status: Operasi Data Gagal";
                        }
                        database.CloseConnection();
                    }
                    else
                    {
                        label_statusAktivitas.Text = "Status: Terdapat input yang tidak valid";
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    label_statusAktivitas.Text = "Status: Input data tidak sesuai";
                }
            }
            else if (this.status == "update" && !string.IsNullOrEmpty(textBox_HargaBarang.Text) || !string.IsNullOrEmpty(textBox_IDData.Text) || !string.IsNullOrEmpty(textBox_jmlBarang.Text) || !string.IsNullOrEmpty(textBox_NamaBarang.Text))
            {
                Tambah_Data.Text = "Update Data";
                try
                {
                    string idBarangString = textBox_IDData.Text;
                    int idBarang;
                    bool isIdBarangValid = int.TryParse(idBarangString, out idBarang);

                    int jumlahBarang;
                    bool isJumlahBarangValid = int.TryParse(jumlahBarangString, out jumlahBarang);

                    decimal hargaBarang;
                    bool isHargaBarangValid = decimal.TryParse(hargaBarangString, out hargaBarang);

                    // Buat query UPDATE awal dengan menyebutkan hanya kolom yang ingin diubah
                    string query = this.query;

                    // Tambahkan setiap kolom yang memiliki nilai tidak null
                    if (!string.IsNullOrEmpty(namaBarang))
                    {
                        query += $" nama_barang = '{namaBarang}',";
                    }

                    if (isJumlahBarangValid)
                    {
                        query += $" jumlah_barang = {jumlahBarang},";
                    }

                    if (isHargaBarangValid)
                    {
                        query += $" harga_barang = {hargaBarang},";
                    }

                    // Hapus koma terakhir dari query
                    query = query.TrimEnd(',');

                    // Tambahkan klausa WHERE untuk memperbarui hanya pada id_barang yang sesuai
                    query += $" WHERE id_barang = {idBarang}";

                    // Eksekusi query UPDATE
                    bool isSuccess = database.ExecuteNonQuery(query);

                    if (isSuccess)
                    {
                        // Tampilkan data terbaru pada Tabel_Barang
                        default_tabel();
                    }

                    database.CloseConnection();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    label_statusAktivitas.Text = "Status: Input data tidak sesuai";
                }
            }
            else if(this.status == "del")
            {
                int idBarang;
                bool isIdBarang = int.TryParse(IDBarang, out idBarang);

                if (isIdBarang)
                {
                    database = new Tugas_CURD_PBO.DatabaseAccess("localhost", "Ini_toko", "postgres", "132435");
                    database.OpenConnection();
                    database.ExecuteNonQuery($"{this.query} WHERE id_barang = {idBarang}");
                    database.CloseConnection();
                }
            }
            else
            {
                label_statusAktivitas.Text = "Status: Colom harus diisi";
            }
        }
    }
}

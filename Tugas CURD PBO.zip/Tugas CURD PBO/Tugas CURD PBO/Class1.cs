﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using System.Data;
using System.Windows.Forms;

namespace Tugas_CURD_PBO
{
    public class DatabaseAccess
    {
        private string connectionString;
        private NpgsqlConnection connection;

        public DatabaseAccess(string server, string database, string username, string password)
        {
            // Membangun string koneksi PostgreSQL
            connectionString = $"Server={server};Port=5432;Database={database};User Id={username};Password={password};";
            connection = new NpgsqlConnection(connectionString);
        }

        public void OpenConnection()
        {
            if (connection.State != ConnectionState.Open)
            {
                connection.Open();
            }
        }

        public void CloseConnection()
        {
            if (connection.State != ConnectionState.Closed)
            {
                connection.Close();
            }
        }

        public DataTable ExecuteQuery(string sqlQuery)
        {
            OpenConnection();
            using (NpgsqlCommand command = new NpgsqlCommand(sqlQuery, connection))
            {
                DataTable dataTable = new DataTable();

                using (NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(command))
                {
                    dataAdapter.Fill(dataTable);
                }
                return dataTable;
            }
        }

        public bool ExecuteNonQuery(string sqlQuery)
        {
            OpenConnection();
            try
            {
                using (NpgsqlCommand command = new NpgsqlCommand(sqlQuery, connection))
                {
                    command.ExecuteNonQuery();
                }
            } catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return false;
            }
            return true;
        }

        public object ExecuteScalar(string query)
        {
            using (var connection = new NpgsqlConnection(connectionString))
            {
                using (var command = new NpgsqlCommand(query, connection))
                {
                    connection.Open();
                    return command.ExecuteScalar();
                }
            }
        }
    }
}
